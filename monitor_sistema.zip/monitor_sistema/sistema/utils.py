import psutil
import platform

def obtener_info_sistema():
    try:
        cpu = psutil.cpu_percent(interval=1)
        ram = psutil.virtual_memory()
        disco = psutil.disk_usage('/')
        sistema = platform.system()
        version = platform.version()
        nucleos = psutil.cpu_count()

        return {
            'cpu': cpu,
            'ram_total': round(ram.total / (1024 ** 3), 2),
            'ram_usada': round(ram.used / (1024 ** 3), 2),
            'ram_percent': ram.percent,
            'disco_total': round(disco.total / (1024 ** 3), 2),
            'disco_usado': round(disco.used / (1024 ** 3), 2),
            'disco_libre': round(disco.free / (1024 ** 3), 2),
            'disco_percent': disco.percent,
            'sistema': sistema,
            'version': version,
            'nucleos': nucleos,
        }
    except Exception as e:
        return {'error': str(e)}
