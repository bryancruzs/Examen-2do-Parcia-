from django.shortcuts import render
from .utils import obtener_info_sistema

def home(request):
    datos = obtener_info_sistema()
    return render(request, 'sistema/home.html', {'datos': datos})
